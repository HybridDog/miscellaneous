LAVA_ANI_S = {name="default_lava_source_animated.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1}}


minetest.register_node(":fire:basic_flame", {
	description = "Feuer",
	drawtype = "nodebox",
	inventory_image = minetest.inventorycube("alphr.png","default_furnace_fire_fg.png","default_furnace_fire_fg.png"),
	tiles = {
		"alphr.png",
		LAVA_ANI_S,
		{name="fire1.png", animation={type="vertical_frames", aspect_w=64, aspect_h=64, length=1}},
		{name="fire1.png", animation={type="vertical_frames", aspect_w=64, aspect_h=64, length=1}},
		{name="fire2.png", animation={type="vertical_frames", aspect_w=64, aspect_h=64, length=1}},
		{name="fire2.png", animation={type="vertical_frames", aspect_w=64, aspect_h=64, length=1}},
	},
	light_source = 14,
	groups = {igniter=2,dig_immediate=3},
	stack_max = 100,
	drop = '',
	walkable = false,
	buildable_to = true,
	selection_box = {
	type = "fixed",
	fixed = {{-0.5,-0.5,-0.5,0.5,0,0.5},},
	},
})







minetest.register_node("tex:dirtywater_flowing", {
	drawtype = "flowingliquid",
	tiles = {"default_water.png"},
	special_tiles = {
		{name="mo_dirtywater_flowing.png", backface_culling=false,	animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1}},
		{name="mo_dirtywater_flowing.png", backface_culling=true,	animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1}},
	},
	alpha = WATER_ALPHA,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	liquidtype = "flowing",
	liquid_alternative_flowing = "tex:dirtywater_flowing",
	liquid_alternative_source = "tex:dirtywater_source",
	liquid_viscosity = WATER_VISC,
	post_effect_color = {a=64, r=100, g=100, b=200},
	groups = {water=3, liquid=3, puts_out_fire=1, not_in_creative_inventory=1},
})

minetest.register_node("tex:dirtywater_source", {
	description = "dreckige Wasserquelle",
	drawtype = "liquid",
	tiles = {
		{name="mo_dirtywater_source.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1.0}}
	},
	special_tiles = {
		-- New-style water source material (mostly unused)
		{name="default_water.png", backface_culling=false},
	},
	alpha = WATER_ALPHA,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	liquidtype = "source",
	liquid_alternative_flowing = "tex:dirtywater_flowing",
	liquid_alternative_source = "tex:dirtywater_source",
	liquid_viscosity = WATER_VISC,
	post_effect_color = {a=64, r=100, g=100, b=200},
	stack_max = 100,
	groups = {water=3, liquid=3, puts_out_fire=1},
})

minetest.register_node(":default:lava_flowing", {
	description = "Flowing Lava",
	drawtype = "flowingliquid",
	tiles = {"default_lava.png"},
	special_tiles = {
		{
			image="default_lava_flowing_animated.png",
			backface_culling=false,
			animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1}
		},
		{
			image="default_lava_flowing_animated.png",
			backface_culling=true,
			animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=3.3}
		},
	},
	paramtype = "light",
	light_source = LIGHT_MAX - 1,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	liquidtype = "flowing",
	liquid_alternative_flowing = "default:lava_flowing",
	liquid_alternative_source = "default:lava_source",
	liquid_viscosity = LAVA_VISC,
	damage_per_second = 4*2,
	post_effect_color = {a=192, r=255, g=64, b=0},
	groups = {lava=3, liquid=2, hot=3, igniter=1, not_in_creative_inventory=1},
})

minetest.register_node(":default:lava_source", {
	description = "Lavaquelle",
	drawtype = "liquid",
	tiles = {LAVA_ANI_S},
	special_tiles = {
		-- New-style lava source material (mostly unused)
		{name="default_lava.png", backface_culling=false},
	},
	paramtype = "light",
	light_source = LIGHT_MAX - 1,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	liquidtype = "source",
	liquid_alternative_flowing = "default:lava_flowing",
	liquid_alternative_source = "default:lava_source",
	liquid_viscosity = LAVA_VISC,
	damage_per_second = 4*2,
	post_effect_color = {a=192, r=255, g=64, b=0},
	stack_max = 100,
	groups = {lava=3, liquid=2, hot=3, igniter=1},
})


minetest.register_node(":default:water_flowing", {
	description = "Flowing Water",
	drawtype = "flowingliquid",
	tiles = {"default_water.png"},
	special_tiles = {
		{name="tex_water_flowing.png", backface_culling=false,	animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1}},
		{name="tex_water_flowing.png", backface_culling=true,	animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1}},
	},
	alpha = WATER_ALPHA,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	liquidtype = "flowing",
	liquid_alternative_flowing = "default:water_flowing",
	liquid_alternative_source = "default:water_source",
	liquid_viscosity = WATER_VISC,
	post_effect_color = {a=64, r=100, g=100, b=200},
	groups = {water=3, liquid=3, puts_out_fire=1, not_in_creative_inventory=1},
})

minetest.register_node(":default:water_source", {
	description = "Wasserquelle",
	drawtype = "liquid",
	tiles = {
		{name="tex_water_still.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=1.0}}
	},
	special_tiles = {
		-- New-style water source material (mostly unused)
		{name="default_water.png", backface_culling=false},
	},
	alpha = WATER_ALPHA,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	liquidtype = "source",
	liquid_alternative_flowing = "default:water_flowing",
	liquid_alternative_source = "default:water_source",
	liquid_viscosity = WATER_VISC,
	post_effect_color = {a=64, r=100, g=100, b=200},
	stack_max = 100,
	groups = {water=3, liquid=3, puts_out_fire=1},
})

minetest.register_node(":default:torch", {
	description = "Fackel",
	drawtype = "torchlike",
	tiles = {-- "default_torch_on_floor.png", "default_torch_on_ceiling.png", "default_torch.png"
		{name="anito.png", animation={type="vertical_frames", aspect_w=64, aspect_h=64, length=3.0}},
		{name="anito_t.png", animation={type="vertical_frames", aspect_w=64, aspect_h=64, length=3.0}},
		{name="anito_s.png", animation={type="vertical_frames", aspect_w=64, aspect_h=64, length=3.0}}
		},
	inventory_image = "default_torch_on_floor.png",
	wield_image = "default_torch_on_floor.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	walkable = false,
	light_source = LIGHT_MAX-1,
	stack_max = 1000,
	selection_box = {
		type = "wallmounted",
		wall_top = {-0.1, 0.5-0.6, -0.1, 0.1, 0.5, 0.1},
		wall_bottom = {-0.1, -0.5, -0.1, 0.1, -0.5+0.6, 0.1},
		wall_side = {-0.5, -0.3, -0.1, -0.5+0.3, 0.3, 0.1},
	},
	groups = {choppy=2,dig_immediate=3,flammable=1},
	sounds = default.node_sound_defaults(),
})




dofile(minetest.get_modpath("tex") .. "/stairs.lua")
