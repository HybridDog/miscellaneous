-- Cotton

minetest.register_craftitem('flowers:cotton', {
    description = "Cotton",
    image = 'cotton.png',
})

minetest.register_craft({
    output = 'wool:white 3',
    recipe ={
	{'flowers:flower_cotton'},
    }
})
