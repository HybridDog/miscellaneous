habitat
=======

adds function for modders to use for spawning for example plants and trees near certain nodes