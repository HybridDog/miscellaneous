--[[
Textures
(edited with gimp)
from:
minetest
gamiano.de
bdcraft.net
warzone2100
...
sounds: GPL
]]

--Tools--------------------
minetest.register_alias("mo:x", "mo:superpick")
minetest.register_tool("mo:superpick", {
	description = "LX 113",
	inventory_image = "mo_pick.png",
	wield_scale = {x=2,y=2,z=2},
	liquids_pointable = true,
	tool_capabilities = {
		full_punch_interval = 0,
		max_drop_level=3,
		groupcaps={
			unbreakable={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			fleshy = {times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			choppy={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			bendy={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			cracky={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			crumbly={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			snappy={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
		}
	},
})
minetest.register_on_punchnode(function(pos, node, puncher)
	if puncher:get_wielded_item():get_name() == "mo:superpick" then
		minetest.env:remove_node(pos)
		puncher:get_inventory():add_item('main', node)
	end
end)
minetest.register_chatcommand("cl", {
	params = "",
	description = "loesche alle items im inventory",
	privs = {give=true},
	func = function(name, param)
		local player = minetest.env:get_player_by_name(name)
		if player == nil then
			print("Unable to pulverize, player is nil")
			return true -- Handled chat message
		end
		if player:get_wielded_item():is_empty() then
			minetest.chat_send_player(name, 'Unable to pulverize, no item in hand.')
		else
			player:set_wielded_item(nil)
			minetest.chat_send_player(name, 'An item was pulverized.')
		end
	end,
})

dofile(minetest.get_modpath("mo") .. "/growing.lua")
dofile(minetest.get_modpath("mo") .. "/mapgen.lua")
dofile(minetest.get_modpath("mo") .. "/objects.lua")
dofile(minetest.get_modpath("mo") .. "/birke.lua")
dofile(minetest.get_modpath("mo") .. "/falling.lua")
dofile(minetest.get_modpath("mo") .. "/papyrus.lua")
dofile(minetest.get_modpath("mo") .. "/sumpf.lua")
dofile(minetest.get_modpath("mo") .. "/mo.lua")
dofile(minetest.get_modpath("mo") .. "/mushroom.lua")
--dofile(minetest.get_modpath("mo") .. "/vulkan.lua")

print "¸___˛ ¸_˛\n| | | |_|"
