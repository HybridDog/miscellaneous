local mo_shoot=function (item, player, pointed_thing)
	local playerpos=player:getpos()
	local obj=minetest.env:add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, "mo:ball_entity")
	local dir=player:get_look_dir()
	obj:setvelocity({x=dir.x*snowball_VELOCITY, y=dir.y*snowball_VELOCITY, z=dir.z*snowball_VELOCITY})
	obj:setacceleration({x=dir.x*-3, y=-dir.y^8*80-snowball_GRAVITY, z=dir.z*-3})
	item:take_item()
	return item
end

mo_ball_ENTITY={
	timer=0,
	physical = false, -- Collides with things
	textures = {'gunmod_bullet1_back.png'},
	lastpos={},
}

mo_ball_ENTITY.on_step = function(self, dtime)
	for _, fly in ipairs({"air", "default:water_flowing", "default:water_source"}) do
	self.timer=self.timer+dtime
	local pos = self.object:getpos()
	local node = minetest.env:get_node(pos)
	local player = minetest.env:get_player_by_name("singleplayer")
	if self.lastpos.x~=nil then --If there is no lastpos for some reason.
		if node.name ~= "air"
		and node.name ~= "default:water_source" then
			player:moveto({x=pos.x, y=pos.y+1, z=pos.z}, false)
			self.object:remove()
			minetest.sound_play("default_place_node", {pos = self.lastpos,	gain = 1.0,	max_hear_distance = 5})
		end
	end
	self.lastpos={x=pos.x, y=pos.y, z=pos.z} -- Set lastpos-->Node will be added at last pos outside the node
end
end

minetest.register_entity("mo:ball_entity", mo_ball_ENTITY)

minetest.register_craftitem("mo:ball", {
	description = "ball",
	stack_max = 1000,
	inventory_image = 'gunmod_bullet1_back.png',
	on_use = mo_shoot,
})
local mo_cannon=function (item, player, pointed_thing)
	local playerpos=player:getpos()
	local obj=minetest.env:add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, "mo:cannon_entity")
	local dir=player:get_look_dir()
	obj:setvelocity({x=dir.x*30, y=dir.y*30, z=dir.z*30})
	obj:setacceleration({x=dir.x, y=-dir.y^8*80-10, z=dir.z})
	item:take_item()
	return item
end

mo_cannon_ENTITY={
	timer=1,
	textures = {'gunmod_bullet1_back.png'},
	lastpos={},
	health = 1,
}
mo_cannon_ENTITY.on_step = function(self, dtime)
	self.timer=self.timer+dtime
	local pos = self.object:getpos()
	local node = minetest.env:get_node(pos)
	local player = minetest.env:get_player_by_name("singleplayer")
		if node.name ~= "air" then
			minetest.env:remove_node(pos)
			self.object:remove()
			minetest.sound_play("default_place_node", {pos = self.lastpos,	gain = 1.0,	max_hear_distance = 5})
		end
	self.lastpos={x=pos.x, y=pos.y, z=pos.z} -- Set lastpos-->Node will be added at last pos outside the node
end

minetest.register_entity("mo:cannon_entity", mo_cannon_ENTITY)

minetest.register_craftitem("mo:bullet", {
	description = "b",
	stack_max = 1000,
	inventory_image = 'gunmod_bullet1_back.png',
	on_use = mo_cannon,
})

