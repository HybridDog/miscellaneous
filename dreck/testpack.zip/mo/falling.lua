local DIRT_1 = {"mo:2","mo:1","mo:gras","mo:wheat","mo:pum"}

timber_nodenames={"default:jungletree", "default:papyrus", "default:cactus", "mo:leaves", "default:leaves", "default:tree", "vines:vine", "vines:vine_rotten", "mo:tree"}

minetest.register_on_dignode(function(pos, node)
	local i=1
	while timber_nodenames[i]~=nil do
		if node.name==timber_nodenames[i] then
			np={x=pos.x, y=pos.y+1, z=pos.z}
			while minetest.env:get_node(np).name==timber_nodenames[i] do
				minetest.env:remove_node(np)
				minetest.env:add_item(np, timber_nodenames[i])
				np={x=np.x, y=np.y+1, z=np.z}
			end
		end
		i=i+1
	end
end)

minetest.register_abm ({
	nodenames = DIRT_1,
	interval = 1,
	chance = 1,
	action = function (pos)
		if minetest.env: get_node({x=pos.x, y=pos.y-1, z=pos.z}).name == "default:dirt_with_grass"
		or minetest.env: get_node({x=pos.x, y=pos.y-1, z=pos.z}).name == "default:dirt"
		or minetest.env: get_node({x=pos.x, y=pos.y-1, z=pos.z}).name == "mo:sumpf"
		or minetest.env:find_node_near(pos, 2, {"ignore"})
			then
			do_preserve = true
		else
			for _, itemname in ipairs(minetest.get_node_drops(minetest.env:get_node(pos).name)) do
				minetest.env:add_item(pos, itemname)
			end
			minetest.env:remove_node(pos)
		end
	end,
})
