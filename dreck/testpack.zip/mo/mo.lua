local SOUND = default.node_sound_stone_defaults()
local A = 190,
--Crafting--------------------
minetest.register_craft({output = 'default:stone',recipe = {{'mo:steinhin'},}})
minetest.register_craft({output = 'mo:marble2 4',recipe = {{'mo:b'},}})
minetest.register_craft({output = 'mo:b',recipe = {
		{'mo:marble2','mo:marble2'},
		{'mo:marble2','mo:marble2'},}})
minetest.register_craft({output = 'mo:schuessel',recipe = {
		{'mo:rinde','',			'mo:rinde'},
		{'',		'mo:rinde',	''},}})
minetest.register_craft({output = 'mo:korb',recipe = {
		{'mo:rinde',		'','mo:rinde'},
		{'mo:rinde',		'','mo:rinde'},
		{'mo:rinde','mo:rinde','mo:rinde'},}})
minetest.register_craft({output = 'mo:rinde 7', recipe = {{'mo:korb'},}})
minetest.register_craft({output = 'mo:trans',recipe = {
		{'default:torch'},
		{'mo:steinhin'},}})
minetest.register_craft({ output = 'default:glass', recipe = {{'mo:trans'},}})
minetest.register_craft({output = 'mo:g',recipe = {
		{'default:dirt','default:dirt','default:dirt'},
		{'default:dirt','mo:a','default:dirt'},
		{'default:dirt','default:dirt','default:dirt'},}})
minetest.register_craft({output = 'mo:pc',recipe = {
		{'default:steel_ingot',	'default:steel_ingot',	'default:steel_ingot'},
		{'default:steel_ingot',			'mo:g',			'default:steel_ingot'},
		{'default:steel_ingot',	'default:steel_ingot',	'default:steel_ingot'},}})
minetest.register_craft({output = 'mo:d',recipe = {
		{'mo:a','mo:g'},
		{'mo:g','mo:a'},}})
minetest.register_craft({output = 'wool:white 4',recipe = {
		{'mo:1','mo:1'},
		{'mo:1','mo:1'},}})
minetest.register_craft({output = 'mo:g',recipe = {{'mo:pc'},}})
minetest.register_craft({output = 'mo:ofs',recipe = {
		{'',	'mo:d',			''		},
		{'mo:d','default:stone','mo:d'	},
		{'',	'mo:d',			''		},}})
minetest.register_craft({output = 'mo:k',recipe = {
		{'mo:blau_lump','mo:blau_lump'},
		{'mo:blau_lump','mo:blau_lump'},}})
minetest.register_craft({output = 'mo:l',recipe = {{'mo:k'},}})
minetest.register_craft({output = 'mo:k',recipe = {{'mo:l'},}})
minetest.register_craft({output = 'mo:radio',recipe = {
		{'default:steel_ingot',	'default:steel_ingot',	'default:steel_ingot'},
		{'default:steel_ingot',			'mo:l',			'default:steel_ingot'},
		{'default:steel_ingot',	'default:steel_ingot',	'default:steel_ingot'},}})
minetest.register_craft({output = 'default:steel_ingot 8',recipe = {{'mo:radio'},}})
minetest.register_craft({output = 'mo:a',recipe = {{'mo:gras'},}})
minetest.register_craft({output = 'mo:sch_pi',recipe = {
		{'mo:2'},
		{'mo:schuessel'},}})
minetest.register_craft({output = 'mo:puml',recipe = {
		{'default:torch'},
		{'mo:pum'},}})
minetest.register_craft({output = 'mo:muffin_roh',recipe = {{'mo:zucker','mo:mehl'},}})
minetest.register_craft({output = 'mo:muffin_roh',recipe = {{'mo:mehl','mo:zucker'},}})
minetest.register_craft({output = 'mo:torte',recipe = {
		{'mo:o','mo:o'},
		{'mo:o','mo:o'},}})
minetest.register_craft({output = 'mo:mehl',recipe = {{'mo:wheat',},}})
minetest.register_craft({output = 'default:wood 6',recipe = {{'stairs:stair_wood',},}})
minetest.register_craft({output = 'mo:f 4',recipe = {{'mo:goldblock'},}})
minetest.register_craft({output = 'mo:goldblock',recipe = {
		{'mo:f','mo:f','mo:f'},
		{'mo:f','mo:f','mo:f'},
		{'mo:f','mo:f','mo:f'},}})
minetest.register_craft({output = 'mo:goldbrick 4',recipe = {
		{'mo:f','mo:f'},
		{'mo:f','mo:f'},}})
minetest.register_craft({output = 'mo:f',recipe = {{'mo:goldbrick'},}})
minetest.register_craft({output = 'mo:f 81',recipe = {{'mo:goldblockblock'},}})
minetest.register_craft({output = 'mo:goldblockblock',recipe = {
		{'mo:goldblock','mo:goldblock','mo:goldblock'},
		{'mo:goldblock','mo:goldblock','mo:goldblock'},
		{'mo:goldblock','mo:goldblock','mo:goldblock'},}})
minetest.register_craft({output = 'mo:fence_stobri 2',recipe = {
		{'mo:stbr', 'mo:stbr', 'mo:stbr'},
		{'mo:stbr', 'mo:stbr', 'mo:stbr'},}})
minetest.register_craft({output = 'mo:stbr 3',recipe = {{'mo:fence_stobri'},}})
minetest.register_craft({output = 'mo:street',recipe = {
		{'mo:stbr','mo:stbr'},
		{'mo:stbr','mo:stbr'},}})
minetest.register_craft({output = 'mo:stbr 4',recipe = {{'mo:street'},}})
minetest.register_craft({output = 'mo:cobble 4',recipe = {
		{'mo:stbr','mo:stbr'},
		{'mo:stbr','mo:stbr'},}})
minetest.register_craft({output = 'mo:stbr',recipe = {{'mo:cobble'},}})
minetest.register_craft({output = 'mo:fence_wand 2',recipe = {
		{'mo:g','mo:g','mo:g'},
		{'mo:g','mo:g','mo:g'},}})
minetest.register_craft({output = 'mo:g 3',recipe = {{'mo:fence_wand'},}})
minetest.register_craft({output = 'mo:g',recipe = {
		{'mo:abw','mo:abw'},
		{'mo:abw','mo:abw'},}})
minetest.register_craft({output = 'default:coal_lump 9',recipe = {{'mo:coalblock'},}})
minetest.register_craft({output = 'mo:coalblock',recipe = {
		{'default:coal_lump','default:coal_lump','default:coal_lump'},
		{'default:coal_lump','default:coal_lump','default:coal_lump'},
		{'default:coal_lump','default:coal_lump','default:coal_lump'},}})
minetest.register_craft({output = 'mo:map',recipe = {
		{'default:paper','default:paper','default:paper'},
		{'default:paper','default:paper','default:paper'},
		{'default:paper','default:paper','default:paper'},}})
minetest.register_craft({output = 'mo:rinde 4',recipe = {
		{'default:tree','default:tree'},
		{'default:tree','default:tree'},}})
minetest.register_craft({output = 'mo:steinhin',recipe = {
		{'default:stick'},
		{'default:stone'},}})
minetest.register_craft({output = 'mo_zucker',recipe = {
	{ 'default:papyrus', 'default:papyrus' },},})

minetest.register_craft({type = "cooking",	output = "mo:e",		recipe = "default:dirt",})
minetest.register_craft({type = "cooking",	output = "mo:stbr",		recipe = "default:wood",})
minetest.register_craft({type = "cooking",	output = "mo:suppe",	recipe = "mo:sch_pi",})
minetest.register_craft({type = "cooking",	output = "mo:abw 10",	recipe = "mo:g",})
minetest.register_craft({type = "cooking",	output = "mo:o",		recipe = "mo:muffin_roh",})
minetest.register_craft({type = "cooking",	output = "mo:f",		recipe = "mo:junglestone",})
minetest.register_craft({type = "cooking",	output = "mo:goldfl",	recipe = "mo:f",})

minetest.register_craft({type = "fuel",		recipe = "mo:gras2",			burntime = 2,})
minetest.register_craft({type = "fuel",		recipe = "mo:o",			burntime = 5,})
minetest.register_craft({type = "fuel",		recipe = "mo:rinde",		burntime = 5,})
minetest.register_craft({type = "fuel",		recipe = "mo:pum",			burntime = 5,})
minetest.register_craft({type = "fuel",		recipe = "mo:wheat",		burntime = 5,})
minetest.register_craft({type = "fuel",		recipe = "mo:pilz",			burntime = 5,})
minetest.register_craft({type = "fuel",		recipe = "mo:gras",			burntime = 5,})
minetest.register_craft({type = "fuel",		recipe = "mo:mehl",			burntime = 5,})
minetest.register_craft({type = "fuel",		recipe = "mo:schuessel",	burntime = 10,})
minetest.register_craft({type = "fuel",		recipe = "mo:map",			burntime = 50,})
minetest.register_craft({type = "fuel",		recipe = "mo:x",			burntime = 50,})


--Node------------------------------------------------------------------------------------
local SCHEIBE = {
	type = "fixed",
	fixed = {{-0.5,	-0.5,	-1/32,		0.5,	0.5,	1/32},},}
local KORB = {
	type = "fixed",
	fixed = {
			{-0.5,	-0.5,	-0.5,		0.5,	-0.49,	0.5},
			{-0.5,	-0.5,	-0.5,		-0.49,	0.5,	0.5},
			{-0.5,	-0.5,	-0.5,		0.5,	0.5,	-0.49},
			{-0.5,	-0.5,	0.49,		0.5,	0.5,	0.5},
			{0.49,	-0.5,	-0.5,		0.5,	0.5,	0.5},
		},
	}


minetest.register_node("mo:trans", {
	description = "Transparenz",
	inventory_image = "alpha.png",
	tile_images = {"alphr.png"},
	drawtype = 'allfaces',
	sunlight_propagates = true,
	paramtype = 'light',
	stack_max = 1000,
	groups = {dig_immediate=3},
	sounds = default.node_sound_dirt_defaults
})
minetest.register_alias("mo:b", "mo:fliesen")
minetest.register_node("mo:fliesen", {
	description = "Fliesen",
	tile_images = {"mo_fliesen.png"},
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:steinhin", {
	description = "kein Stein",
	tile_images = {"default_stone.png"},
	walkable = false,
	stack_max = 1000,
	groups = {cracky=3,oddly_breakable_by_hand=3},
	sounds = SOUND,
})
minetest.register_node("mo:stbr", {
	description = "Stone Brick",
	tile_images = {"mo_stobri.png"},
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:cobble", {
	description = "Pflasterstein",
	tile_images = {"mo_cobble.png"},
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_alias("mo:marble2", "mo:marble")
minetest.register_node("mo:marble2", {
	description = "Marmor",
	tile_images = {"mo_marble.png"},
	stack_max = 200,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:marble_erz", {
	tile_images = {"mo_marble_erz.png"},
	drop = 'mo:marble2',
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:map", {
	description = "Land",
	tile_images = {"mo_land.png"},
	stack_max = 128,
	groups = {dig_immediate=3},
	sounds = default.node_sound_dirt_defaults
})
minetest.register_alias("mo:d", "mo:all")
minetest.register_node("mo:all", {
	description = "All",
	tile_images = {"mo_all.png"},
	stack_max = 128,
	groups = {dig_immediate=3},
	sounds = default.node_sound_dirt_defaults
})
minetest.register_alias("mo:e", "mo:dirt_dry")
minetest.register_node("mo:dirt_dry", {
	description = "getrockneter Dreck",
	tile_images = {"mo_dry.png"},
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_alias("mo:f", "mo:gold")
minetest.register_node("mo:gold", {
	description = "Gold?",
	tile_images = {"mo_gold.png"},
	stack_max = 128,
	groups = {cracky=3},
	light_source = 200,
	sounds = SOUND,
})
minetest.register_node("mo:goldbrick", {
	description = "Goldbrick",
	tile_images = {"mo_goldbrick.png"},
	light_source = LIGHT_MAX-1,
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:goldblock", {
	description = "Gold?block",
	tile_images = {"mo_gobl.png"},
	light_source = LIGHT_MAX-1,
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:goldblockblock", {
	description = "Gold?blockblock",
	tile_images = {"mo_goblbl.png"},
	light_source = LIGHT_MAX-1,
	stack_max = 1000,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_alias("mo:g", "mo:special")
minetest.register_node("mo:special", {
	description = "W",
	tile_images = {"mo_wa.png"},
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:rinde", {
	description = "Baumrinde",
	tile_images = {"mo_rinde.png"},
	stack_max = 128,
	groups = {crumbly=3},
	sounds = default.node_sound_dirt_defaults
})
minetest.register_node("mo:tort", {
	tile_images = {"mo_to_t.png", "mo_to_b.png", "mo_to_s2.png"},
	groups = {crumbly=2},
	stack_max = 1,
	drop = 'mo:torte 2',
	sounds = default.node_sound_dirt_defaults
})
minetest.register_node("mo:torte", {
	description = "Torte",
	drawtype = "nodebox",
	tiles = {"mo_to_t.png", "mo_to_b.png", "mo_to_s.png"},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	stack_max = 128,
	groups = {crumbly=3},
	sounds = default.node_sound_dirt_defaults,
	on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local slabpos = nil
			local slabnode = nil
			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local n0 = minetest.env:get_node(p0)
			local n1 = minetest.env:get_node(p1)
			if n0.name == "mo:torte" then
				slabpos = p0
				slabnode = n0
			elseif n1.name == "mo:torte" then
				slabpos = p1
				slabnode = n1
			end
			if slabpos then
				minetest.env:remove_node(slabpos)
				local fakestack = ItemStack('mo:tort')
				pointed_thing.above = slabpos
				fakestack = minetest.item_place(fakestack, placer, pointed_thing)
				if not fakestack or fakestack:is_empty() then
					itemstack:take_item(1)
				else
					minetest.env:set_node(slabpos, slabnode)
				end
				return itemstack
			end
			
			return minetest.item_place(itemstack, placer, pointed_thing)
		end,
	
})
minetest.register_alias("mo:i", "mo:blauerz")
minetest.register_node("mo:blauerz", {
	description = "Blauerz",
	tile_images = {"default_stone.png^mo_blauerz.png"},
	stack_max = 1,
	groups = {cracky=3},
	drop = 'mo:blau_lump 8',
	sounds = SOUND,
})
minetest.register_alias("mo:k", "mo:blau")
minetest.register_node("mo:blau", {
	description = "Blau",
	tile_images = {"mo_blau.png"},
	post_effect_color = {a=190, r=0, g=0, b=200},
	stack_max = 200,
	groups = {cracky=3},
	drop = 'mo:blau_lump 4',
	sounds = SOUND,
})
minetest.register_node("mo:hausblock", {
	description = "Hausblock",
	tile_images = {"default_stone.png", "default_wood.png", "mo_wand.png"},
	stack_max = 1024,
	groups = {cracky=2},
	sounds = SOUND,
})

minetest.register_node("mo:korb", {
	description = "Korb",
	drawtype = "nodebox",
	tile_images = {"mo_abw.png","mo_abw.png","mo_abw.png"},
	stack_max = 128,
	groups = {cracky=1},
	sounds = SOUND,
	paramtype = "light",
	paramtype2 = "facedir",
	node_box = KORB,
	selection_box = KORB,
	sounds = SOUND,
})

minetest.register_node("mo:glas", {
	description = "Glasscheibe",
	drawtype = "nodebox",
	tile_images = {"mo_sta.png","mo_sta.png","mo_sta2.png","mo_sta2.png","default_glass.png","default_glass.png"},
	inventory_image = "default_glass.png",
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	stack_max = 128,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	sounds = default.node_sound_glass_defaults(),
	node_box = SCHEIBE,
	selection_box = SCHEIBE,
})
minetest.register_alias("mo:l", "mo:acid")
minetest.register_node("mo:acid", {
	description = "XXX",
	tile_images = {"mo_desert.png"},
	drawtype = "liquid",
	stack_max = 128,
	groups = {dig_immediate=3,puts_out_fire=1},
	liquidtype = "source",
	walkable = false,
	alpha = A,
	drop = 'mo:l 2',
	sounds = SOUND,
})

minetest.register_node("mo:ofs", {
	description = "One Footstep",
	tile_images = {"mo_ofs.png"},
	stack_max = 128,
	groups = {dig_immediate=3,puts_out_fire=1},
	sounds = SOUND,
})
minetest.register_node("mo:coalblock", {
	description = "Kohleblock",
	tile_images = {"mo_coalblock.png"},
	stack_max = 128,
	groups = {dig_immediate=3},
	sounds = SOUND,
})


----------------------------------------plants----------------------------------------------------------------------------
minetest.register_node("mo:pum", {
	description = "Kuerbis",
	tiles = {"mo_pum_t.png", "mo_pum_b.png", "mo_pum_s.png",
		"mo_pum_s.png", "mo_pum_s.png", "mo_pum_v.png"},
	paramtype2 = "facedir",
	wield_image = "mo_pum_s.png",
	on_use = minetest.item_eat(4),
	stack_max = 128,
	groups = {snappy=3},
	sounds = SOUND,
})
minetest.register_node("mo:puml", {
	description = "Kuerbislaterne",
	tiles = {"mo_pum_t.png", "mo_pum_b.png", "mo_pum_s.png",
		"mo_pum_s.png", "mo_pum_s.png", "mo_pum_vl.png"},
	paramtype2 = "facedir",
	wield_image = "mo_pum_s.png",
	light_source = LIGHT_MAX-1,
	stack_max = 105,
	groups = {snappy=3},
	sounds = SOUND,
})
minetest.register_node("mo:wheat", {
	description = "Weizen",
	tile_images = {"mo_weiz.png"},
	inventory_image = "mo_weiz.png",
	wield_image = "mo_weiz.png",
	drawtype = "plantlike",
	paramtype = "light",
	selection_box = {type = "fixed",fixed = {-1/3, -1/2, -1/3, 1/3, 1/4, 1/3},},
	walkable = false,
	stack_max = 128,
	groups = {fleshy=3,flammable=2},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("mo:gras", {
	description = "#special<89>",
	tile_images = {"mo_gras.png"},
	inventory_image = "mo_gras.png",
	wield_image = "mo_gras.png",
	drawtype = "plantlike",
	paramtype = "light",
	selection_box = {type = "fixed",fixed = {-1/3, -1/2, -1/3, 1/3, 1/4, 1/3},},
	walkable = false,
	stack_max = 128,
	groups = {fleshy=3,flammable=2},
	sounds = default.node_sound_leaves_defaults(),
})
---------------------------------------------------pl-----------------------------------------------------------------



minetest.register_node("mo:street", {
	description = "Street",
	drawtype = "raillike",
	tile_images = {"mo_street.png", "mo_street_ku.png", "mo_street_t.png", "mo_street_kr.png"},
	inventory_image = "mo_street.png",
	wield_image = "mo_street.png",
	paramtype = "light",
	walkable = false,
	selection_box = {type = "fixed",fixed = {-0.5, -1/2, -0.5, 0.5, -0.45, 0.5},},
	stack_max = 128,
	groups = {bendy=2,snappy=1,dig_immediate=2},
	sounds = default.node_sound_defaults(),
})
minetest.register_node('mo:radio', {
	description = "!!!",
	drawtype = 'raillike',
	tile_images = { 'mo_radi.png', },
	inventory_image = 'mo_radi.png',
	selection_box = {type = "fixed",fixed = {-0.5, -1/2, -0.5, 0.5, -0.45, 0.5},},
	paramtype = 'light',
	walkable = false,
	stack_max = 128,
	groups = {dig_immediate=3},
	sounds = default.node_sound_defaults(),
})
minetest.register_node('mo:abw', {
	description = "Schutz",
	drawtype = 'raillike',
	tile_images = { 'mo_abw.png', },
	inventory_image = 'mo_abw.png',
	selection_box = {type = "fixed",fixed = {-0.5, -1/2, -0.5, 0.5, -0.45, 0.5},},
	paramtype = 'light',
	walkable = false,
	stack_max = 500,
	groups = {dig_immediate=3,puts_out_fire=1},
	sounds = default.node_sound_defaults(),
})
minetest.register_node('mo:pc', {
	description = "PC",
	drawtype = 'signlike',
	tile_images = { 'mo_pc.png', },
	inventory_image = 'mo_pc.png',
	selection_box =	{type = "wallmounted",},
	paramtype = 'light',
	paramtype2 = "wallmounted",
	legacy_wallmounted = true,
	walkable = false,
	stack_max = 500,
	groups = {snappy=1,choppy=2,oddly_breakable_by_hand=3},
	sounds = default.node_sound_defaults(),
})


minetest.register_node("mo:fence_stobri", {
	description = "Stonebrickzaun",
	drawtype = "fencelike",
	tiles = {"mo_stobri.png"},
	inventory_image = "mo_fence_stobri.png",
	wield_image = "mo_fence_stobri.png",
	paramtype = "light",
	selection_box = {
		type = "fixed",
		fixed = {-1/7, -1/2, -1/7, 1/7, 1/2, 1/7},
	},
	stack_max = 128,
	groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2},
	sounds = SOUND,
})
minetest.register_node("mo:fence_wand", {
	description = "Specialzaun",
	drawtype = "fencelike",
	tiles = {"mo_wa.png"},
	inventory_image = "mo_fence_wand.png",
	wield_image = "mo_fence_wand.png",
	paramtype = "light",
	selection_box = {
		type = "fixed",
		fixed = {-1/7, -1/2, -1/7, 1/7, 1/2, 1/7},
	},
	stack_max = 128,
	groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2},
	sounds = SOUND,
})

minetest.register_alias("mo:o", "mo:muffin")
minetest.register_node("mo:muffin", {
	description = "Muffin",
	inventory_image = "mo_ku.png",
	tile_images = {"mo_ku.png"},
	drawtype = "plantlike",
	paramtype = "light",
	selection_box = {type = "fixed",fixed = {-0.3, -0.5, -0.3, 0.3, 0.35, 0.3},},
	walkable = false,
	on_use = minetest.item_eat(20),
	stack_max = 128,
	groups = {dig_immediate=3},
	sounds = default.node_sound_defaults(),
})
minetest.register_node("mo:suppe", {
	description = "Pilzsuppe",
	drawtype = "plantlike",
	tile_images = {"mo_suppe.png"},
	inventory_image = "mo_suppe.png",
	paramtype = "light",
	walkable = false,
	stack_max = 128,
	groups = {fleshy=3,dig_immediate=3},
	on_use = minetest.item_eat(10),
	sounds = default.node_sound_defaults(),
})


minetest.register_craftitem("mo:blau_lump", {
	description = "Ore",
	inventory_image = "mo_lump.png",
	stack_max = 128,
})
minetest.register_craftitem("mo:schuessel", {
	description = "Schuessel",
	inventory_image = "mo_schues.png",
	stack_max = 16,
})
minetest.register_craftitem("mo:sch_pi", {
	description = "Schuessel mit Pilz",
	inventory_image = "mo_sch_pi.png",
	stack_max = 16,
})
minetest.register_craftitem("mo:mehl", {
	description = "Mehl",
	inventory_image = "mo_me.png",
	stack_max = 16,
})
minetest.register_craftitem("mo:zucker", {
    description = "Zucker",
    inventory_image = "mo_zucker.png",
    on_use = minetest.item_eat(1),
})
minetest.register_craftitem("mo:muffin_roh", {
	description = "In den Ofen damit!",
	inventory_image = "mo_kur.png",
	stack_max = 16,
})
