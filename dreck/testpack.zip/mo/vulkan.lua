VULKANGROUND = {"default:dirt_with_grass","default:sand","default:desert_sand"}
EVVULKANGROUND = {"default:dirt_with_grass","default:sand","default:desert_sand", "default:water_source"}
minetest.register_on_generated(function(minp, maxp, seed)
	if maxp.y >= -10
	and maxp.y <= 200
	and minp.y >= -10
		then
		-- Assume X and Z lengths are equal
		local divs = (maxp.x-minp.x);
		local x0 = minp.x
		local z0 = minp.z
		local x1 = maxp.x
		local z1 = maxp.z

		local env = minetest.env

		local perlin1 = env:get_perlin(22,3, 0.5, 200)
			pr = PseudoRandom(seed+68)

		if not (perlin1:get2d({x=x0, y=z0}) > 0.53) and not (perlin1:get2d({x=x1, y=z1}) > 0.53)
		and not (perlin1:get2d({x=x0, y=z1}) > 0.53) and not (perlin1:get2d({x=x1, y=z0}) > 0.53)
		and not (perlin1:get2d({x=(x1-x0)/2, y=(z1-z0)/2}) > 0.53) then
			print("abort vulkan")
			return
		end

		for j=0,divs do
			for i=0,divs do

				local x = x0+i
				local z = z0+j

				local bi = pr:next(1,2) == 1

				local test = perlin1:get2d({x=x, y=z})
				if test > 0.53 then

					local ground_y = nil
					for _, ground in ipairs(VULKANGROUND) do
							for y=maxp.y,0,-1 do
							if env:get_node({x=x,y=y,z=z}).name == ground then
								ground_y = y
								break
						end

						if ground_y
						and env:get_node({x=x,y=ground_y,z=z}).name == ground then
							if bi then
								if pr:next(1,400) == 1 then
									env:add_node({x=x,y=ground_y+1,z=z}, {name="default:lava_source"})
							end
							else
								env:add_node({x=x,y=ground_y,z=z}, {name="lavacooling:obsidian"})
							end
								for l=-30,0,1 do
									env:add_node({x=x,y=ground_y+l,z=z}, {name="lavacooling:obsidian"})
							end
					end
					end
				end
				end
			end
		end
		local geninfo = "Vulkan generiert: (x="..minp.x..") (z="..minp.z..")"
		--print(geninfo)
		minetest.chat_send_all(geninfo)
	end
end
)
