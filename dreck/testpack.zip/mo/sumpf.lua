minetest.register_alias("mo:a", "mo:junglestone")
minetest.register_alias("mo:1", "mo:gras2")
minetest.register_alias("mo:2", "mo:pilz")
local MUSH = {
		type = "fixed",
		fixed = {
			{-0.15, -0.2, -0.15, 0.15, -0.1, 0.15},
			{-0.2, -0.3, -0.2, 0.2, -0.2, 0.2},
			{-0.05, -0.5, -0.05, 0.05, -0.3, 0.05},
		},
	}
minetest.register_node("mo:pilz", {
	description = "Pilz",
	tile_images = {"mo_pilz_t.png","mo_dry.png","mo_pilz_s.png"},
	inventory_image = "mo_be.png",
	drawtype = "nodebox",
	paramtype = "light",
	node_box = MUSH,
	selection_box = MUSH,
	walkable = false,
	stack_max = 128,
	groups = {fleshy=2,flammable=2},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("mo:gras2", {
	description = "Gras",
	tile_images = {"mo_grass_small.png"},
	inventory_image = "mo_grass_small.png",
	drawtype = "plantlike",
	paramtype = "light",
	selection_box = {type = "fixed",fixed = {-1/3, -1/2, -1/3, 1/3, -1/5, 1/3},},
	buildable_to = true,
	walkable = false,
	stack_max = 64,
	groups = {fleshy=2,flammable=2},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("mo:junglestone", {
	description = "jungledirt",
	tile_images = {"mo_junglestone.png"},
	stack_max = 128,
	groups = {cracky=3},
	sounds = SOUND,
})
minetest.register_node("mo:sumpf", {
	description = "Sumpf",
	tiles = {"mo_sumpf.png"},
	groups = {crumbly=3},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name="sumpf", gain=0.4},
	}),
})
minetest.register_node("mo:sumpf2", {
	tiles = {"mo_sumpf.png","mo_junglestone.png","mo_sumpf2.png"},
	groups = {cracky=3},
	drop = "mo:junglestone",
	sounds = default.node_sound_stone_defaults({
		footstep = {name="sumpf", gain=0.4},
	}),
})

SUMPFGROUND	=	{"default:dirt_with_grass","default:dirt","default:sand","default:desert_sand"}
EVSUMPFGROUND =	{"default:dirt_with_grass","default:dirt","default:sand","default:desert_sand", "default:water_source"}
minetest.register_on_generated(function(minp, maxp, seed)
	if maxp.y >= -10
	and maxp.y <= 200
	and minp.y >= -10
		then
		-- Assume X and Z lengths are equal
		local divs = (maxp.x-minp.x);
		local x0,z0,x1,z1,env = minp.x,minp.z,maxp.x,maxp.z,minetest.env
		local perlin1 = env:get_perlin(11,3, 0.5, 200)
			pr = PseudoRandom(seed+68)

		if not (perlin1:get2d({x=x0, y=z0}) > 0.53) and not (perlin1:get2d({x=x1, y=z1}) > 0.53)
		and not (perlin1:get2d({x=x0, y=z1}) > 0.53) and not (perlin1:get2d({x=x1, y=z0}) > 0.53)
		and not (perlin1:get2d({x=(x1-x0)/2, y=(z1-z0)/2}) > 0.53) then
			print("abortsumpf")
			return
		end

		for j=0,divs do
			for i=0,divs do
				local x,z = x0+i,z0+j
				local bi = pr:next(1,2) == 1
				local test = perlin1:get2d({x=x, y=z})
				if test > 0.53 then

					local ground_y = nil
					for _, ground in ipairs(SUMPFGROUND) do
						for _, evground in ipairs(EVSUMPFGROUND) do
							for y=maxp.y,0,-1 do
							if env:get_node({x=x,y=y,z=z}).name == evground then
								ground_y = y
								break
							end
						end

						if ground_y
						and env:get_node({x=x,y=ground_y,z=z}).name == ground then
							if bi then
								if pr:next(1,40) == 1 then
									env:add_node({x=x,y=ground_y+1,z=z}, {name="mo:birk"})
								elseif pr:next(1,10) == 1 then
									env:add_node({x=x,y=ground_y+1,z=z}, {name="jungletree:sapling"})
								elseif pr:next(1,25) == 1 then
									env:add_node({x=x,y=ground_y+1,z=z}, {name="mo:pilz"})
								elseif pr:next(1,2) == 1 then
									env:add_node({x=x,y=ground_y+1,z=z}, {name="mo:gras2"})
								elseif pr:next(1,3) == 1 then
									env:add_node({x=x,y=ground_y+1,z=z}, {name="default:junglegrass"})
								end
--							else
	--							env:add_node({x=x,y=ground_y,z=z}, {name="mo:sumpf"})
							end
								if pr:next(1,4) == 1
								and env:get_node({x=x+1,y=ground_y,z=z}).name ~= "air"
								and env:get_node({x=x-1,y=ground_y,z=z}).name ~= "air"
								and env:get_node({x=x,y=ground_y,z=z+1}).name ~= "air"
								and env:get_node({x=x,y=ground_y,z=z-1}).name ~= "air"  then
									for s=-30,0,1 do
										env:add_node({x=x,y=ground_y+s,z=z}, {name="tex:dirtywater_source"})
										env:add_node({x=x,y=ground_y+1--[[-s]],z=z}, {name="air"})
									end
								else
									for i=-3,-30,-1 do
										for l=-1,0,1 do
											if env:get_node({x=x,y=ground_y+i,z=z}).name ~= "air" then
												env:add_node({x=x,y=ground_y+l,z=z}, {name="mo:sumpf"})
												env:add_node({x=x,y=ground_y-2,z=z}, {name="mo:sumpf2"})
												env:add_node({x=x,y=ground_y+i,z=z}, {name="mo:junglestone"})
											else break
											end
										end
									end
								end
							else if ground_y
							and env:get_node({x=x,y=ground_y,z=z}).name == "default:water_source" then
								for y=0,-30,-1 do
									if env:get_node({x=x,y=ground_y+y,z=z}).name == "default:water_source" then
										env:add_node({x=x,y=ground_y+y,z=z}, {name="tex:dirtywater_source"})
									else
										env:add_node({x=x,y=ground_y+y+1,z=z}, {name="mo:junglestone"})
										break
									end
								end
							end
						end
					end
					end
				end
			end
		end
					local geninfo = "-#- Sumpf generiert: (x="..minp.x..") (z="..minp.z..")"
					print(geninfo)
					minetest.chat_send_all(geninfo)
	end
end
)
