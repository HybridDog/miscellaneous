--------------------------------------papyrus----------------------------------------
MO_PAPYRUS = {
			type = "fixed",
			fixed = {
				--papyrus 1
				{-0.03-0.1,-0.5,-0.03-0.1, 0.03-0.1,0.5,0.03-0.1},
				{-0.06-0.1,-0.02-0.1,-0.06-0.1, 0.06-0.1,0.02-0.1,0.06-0.1},
				--papyrus 2
				{-0.03-0.4,-0.5,-0.03-0.3, 0.03-0.4,0.5,0.03-0.3},
				{-0.06-0.4,-0.02-0.2,-0.06-0.3, 0.06-0.4,0.02-0.2,0.06-0.3},
				--papyrus 3
				{-0.03+0.4,-0.5,-0.03-0.3,0.03+0.4,0.5,0.03-0.3},
				{-0.06+0.4,-0.02+0.2,-0.06-0.3, 0.06+0.4,0.02+0.2,0.06-0.3},
				--papyrus 4
				{-0.03-0.4,-0.5,-0.03+0.4, 0.03-0.4,0.5,0.03+0.4},
				{-0.06-0.4,0.02+0.4,-0.06+0.4, 0.06-0.4,0.02+0.4,0.06+0.4},
				--papyrus 5
				{-0.03-0.2,-0.5,-0.03+0.2, 0.03-0.2,0.5,0.03+0.2},
				{-0.06-0.2,0.02-0.4,-0.06+0.2, 0.06-0.2,0.02-0.4,0.06+0.2},
				--papyrus 6
				{-0.03+0.1,-0.5,-0.03+0.2, 0.03+0.1,0.5,0.03+0.2},
				{-0.06+0.1,0.02+0.3,-0.06+0.2, 0.06+0.1,0.02+0.3,0.06+0.2},
				},
			}

minetest.register_node("mo:papyrus_rotten1",
		{drawtype	=	"nodebox",
				tiles	=	{ "mo_papyrus_rotten1.png" },
			paramtype	=	"light",
	is_ground_content	=	true,
			walkable	=	false,
		drop 			= 	{max_items = 1, items = {{items = {"default:papyrus"},}}},
		node_box 		= 	MO_PAPYRUS,
		groups 			= 	{snappy = 3,flammable = 2},
		sounds 			= 	default.node_sound_leaves_defaults(),
	})
minetest.register_node("mo:papyrus_rotten2",
		{drawtype	=	"nodebox",
				tiles	=	{ "mo_papyrus_rotten2.png" },
			paramtype	=	"light",
	is_ground_content	=	true,
			walkable	=	false,
		drop 			= 	{max_items = 1, items = {{items = {"default:papyrus"},}}},
		node_box 		= 	MO_PAPYRUS,
		groups 			= 	{snappy = 3,flammable = 2},
		sounds 			= 	default.node_sound_leaves_defaults(),
	})

--need water
minetest.register_abm ({
	nodenames = {"default:papyrus"},
	interval = 2,
	chance = 3,
	action = function (pos)
		local under = minetest.env:get_node({x=pos.x, y=pos.y-1, z=pos.z}).name
		if minetest.env:find_node_near(pos, 1, {"default:water_source","default:water_flowing"})
		or under == "default:papyrus"
		or minetest.env:find_node_near(pos, 2, {"ignore"})
		then
		return
		else
		minetest.env: add_node (pos, {name = "mo:papyrus_rotten1"})
		end
	end,
})
minetest.register_abm ({
	nodenames = {"mo:papyrus_rotten1"},
	interval = 2,
	chance = 3,
	action = function (pos)
		local under = minetest.env:get_node({x=pos.x, y=pos.y-1, z=pos.z}).name
		if minetest.env:find_node_near(pos, 1, {"default:water_source","default:water_flowing"})
		or under == "default:papyrus"
		or minetest.env:find_node_near(pos, 2, {"ignore"})
		then
		return
		else
		minetest.env: add_node (pos, {name = "mo:papyrus_rotten2"})
		end
	end,
})
minetest.register_abm ({
	nodenames = {"mo:papyrus_rotten1"},
	interval = 2,
	chance = 3,
	action = function (pos)
		local under = minetest.env:get_node({x=pos.x, y=pos.y-1, z=pos.z}).name
		if minetest.env:find_node_near(pos, 2, {"ignore"})
			then return
		else
		if minetest.env:find_node_near(pos, 1, {"default:water_source","default:water_flowing"})
			then
			minetest.env: add_node (pos, {name = "default:papyrus"})
			end
		end
	end,
})
minetest.register_abm ({
	nodenames = {"mo:papyrus_rotten2"},
	interval = 2,
	chance = 3,
	action = function (pos)
		local under = minetest.env:get_node({x=pos.x, y=pos.y-1, z=pos.z}).name
		if under == "default:papyrus"
		or minetest.env:find_node_near(pos, 2, {"ignore"})
		then
		return
		else
		minetest.env:remove_node(pos)
		end
	end,
})
--growing
minetest.register_abm ({
	nodenames = {"default:papyrus"},
	interval = 2,
	chance = 3,
	action = function (pos)
		local about = minetest.env:get_node({x=pos.x, y=pos.y+1, z=pos.z}).name
		if minetest.env:get_node({x=pos.x, y=pos.y-7, z=pos.z}).name == "default:papyrus"
		then return
		else
			if about == "air"
				then
				minetest.env: add_node ({x=pos.x, y=pos.y+1, z=pos.z}, {name = "default:papyrus"})
			end
		end
	end,
})
--[[
	minetest.register_abm ({
	nodenames = {"default:papyrus"},
	interval = 2,
	chance = 2,
	action = function (pos)
		if minetest.env:get_node({x=pos.x, y=pos.y-7, z=pos.z}).name == "default:papyrus"
		then
			local n0 = minetest.env:get_node(pos)
			itemstacks = minetest.get_node_drops(n0.name)
			for _, itemname in ipairs(itemstacks) do
				if itemname ~= n0.name
				then
				minetest.env:add_item(pos, itemname)
				end
			end
		minetest.env:remove_node(pos)
		end
	end,
})
--]]
