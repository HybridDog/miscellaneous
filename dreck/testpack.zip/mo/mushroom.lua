minetest.register_node("mo:pilzsapling", {
	description = "Riesenpilz",
	tile_images = {"mo_pilzstammm.png"},
	stack_max = 128,
	groups = {oddly_breakable_by_hand=3},
})
minetest.register_node("mo:pilzstammm", {
	description = "Pilzstammm",
	tile_images = {"birke_tree_top.png","birke_tree_top.png","mo_pilzstammm.png"},
	stack_max = 128,
	groups = {oddly_breakable_by_hand=3},
})
minetest.register_node("mo:pilzkappe", {
	description = "Pilzkappe",
	tile_images = {"mo_pilzkappe.png"},
	stack_max = 128,
	groups = {oddly_breakable_by_hand=3},
})
minetest.register_node("mo:pilzkappe2", {
	description = "Lam",
	tile_images = {"mo_dry.png"},
	stack_max = 128,
	groups = {oddly_breakable_by_hand=3},
})

minetest.register_abm({
	nodenames = {"mo:pilzsapling"},
	interval = 10,
	chance = 10,
	action = function(pos, node)
	local random = math.random(3)
	local height = 2 + random
	local breite = random
	local br = breite+1

	for i = height, 0, -1 do
		local p = {x=pos.x, y=pos.y+i, z=pos.z}
		minetest.env:add_node(p, {name="mo:pilzstammm"})
	end

	for j = -br, br, 1 do
		for k = -br, br, 1 do
			local o = {x=pos.x+j, y=pos.y+height, z=pos.z+k}
	  		if	k == br
	  		or	k == -br
	  		or	j == br
	  		or	j == -br	then
				minetest.env:add_node(o, {name="mo:pilzkappe"})
			else
				minetest.env:add_node(o, {name="mo:pilzkappe2"})
			end
		end
	end

	for l = -breite, breite, 1 do
		for m = -breite, breite, 1 do
			local n = {x=pos.x+l, y=pos.y+height+1, z=pos.z+m}
			minetest.env:add_node(n, {name="mo:pilzkappe"})
		end
	end
end,
})
