minetest.register_node("sumpf:sapling", {
	description = "Birch",	
	drawtype = "plantlike",	
	tiles = {"birke_sapling.png"},	
	inventory_image = "birke_sapling.png",	
	wield_image = "birke_sapling.png",	
	paramtype = "light",	
	walkable = false,	
	stack_max = 1024,
	groups = {snappy=2,dig_immediate=3,flammable=2},
})
minetest.register_node("sumpf:birk", {
	tiles = {"birke_mossytree.png"},	
	inventory_image = "birke_sapling.png",	
	paramtype = "light",	
	stack_max = 1024,
	groups = {snappy=2,dig_immediate=3},
})

minetest.register_node("sumpf:leaves", {
	description = "Birch Leaves",
	drawtype = "glasslike",
	tiles = {"birke_leaves.png"},
	paramtype = "light",
	stack_max = 64,
	groups = {snappy=3, leafdecay=3, flammable=2},
	drop = {
		max_items = 1,
		items = {
			{
				items = {'sumpf:sapling'},
				rarity = 20,
			},
			{
				items = {'sumpf:leaves'},
				rarity = 20,
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("sumpf:tree", {
	description = "Birch Trunk",	
	tiles = {"birke_tree_top.png",	"birke_tree_top.png",	"birke_tree.png"},	
	is_ground_content = true,	
	stack_max = 64,
	groups = {tree=1,snappy=1,choppy=2,oddly_breakable_by_hand=1,flammable=2},
})

minetest.register_node("sumpf:mossytree", {
	description = "Mossy Birch Trunk",	
	tiles = {"birke_tree_top.png",	"sumpf.png",	"birke_mossytree.png"},	
	is_ground_content = true,	
	stack_max = 64,
	groups = {tree=1,snappy=1,choppy=2,oddly_breakable_by_hand=1,flammable=2},
})

minetest.register_craft({
	output = 'default:wood 4',
	recipe = {
		{ 'sumpf:tree' },
	}
})

local function add_tree_branch(pos)	
	minetest.env:add_node(pos, {name="sumpf:tree"})	
	for i = math.floor(math.random(2)), -math.floor(math.random(2)), -1 do		
		for k = math.floor(math.random(2)), -math.floor(math.random(2)), -1 do			
			local p = {x=pos.x+i, y=pos.y, z=pos.z+k}			
			local n = minetest.env:get_node(p)						
			if (n.name=="air") then				
				minetest.env:add_node(p, {name="sumpf:leaves"})			
			end						
			local chance = math.abs(i+k)						
			if (chance < 1) then				
				p = {x=pos.x+i, y=pos.y+1, z=pos.z+k}				
				n = minetest.env:get_node(p)				
				if (n.name=="air") then					
					minetest.env:add_node(p, {name="sumpf:leaves"})			   
				end			
			end		
		end	
	end
end
mache_birke = function(pos, node)				
		local height = 3 + math.random(2)				
--		if height < 10 then			
			for i = height, 1, -1 do								
				local p = {x=pos.x, y=pos.y+i, z=pos.z}				
				minetest.env:add_node(p, {name="sumpf:tree"})								
				if i == height then										

					add_tree_branch({x=pos.x, y=pos.y+height+math.random(0, 1), z=pos.z})										
					add_tree_branch({x=pos.x+1, y=pos.y+i-math.random(2), z=pos.z})					
					add_tree_branch({x=pos.x-1, y=pos.y+i-math.random(2), z=pos.z})					
					add_tree_branch({x=pos.x, y=pos.y+i-math.random(2), z=pos.z+1})					
					add_tree_branch({x=pos.x, y=pos.y+i-math.random(2), z=pos.z-1})								
				end								
				if height <= 0 then					
					minetest.env:add_node({x=pos.x+1, y=pos.y+i-math.random(2), z=pos.z}, {name="sumpf:tree"})					
					minetest.env:add_node({x=pos.x, y=pos.y+i-math.random(2), z=pos.z+1}, {name="sumpf:tree"})					
					minetest.env:add_node({x=pos.x-1, y=pos.y+i-math.random(2), z=pos.z}, {name="sumpf:tree"})					
					minetest.env:add_node({x=pos.x, y=pos.y+i-math.random(2), z=pos.z-1}, {name="sumpf:tree"})				
				end				
				if (math.sin(i/height*i) < 0.2 and i > 3 and math.random(0,2) < 1.5) then					
					branch_pos = {x=pos.x+math.random(0,1), y=pos.y+i, z=pos.z-math.random(0,1)}					
					add_tree_branch(branch_pos)				
				end			
				minetest.env:add_node(pos, {name="sumpf:mossytree"})								
			end		
--		end	
	end

minetest.register_abm({	
	nodenames = {"sumpf:sapling"},	
	interval = 10,	
	chance = 6,	
	action = mache_birke
,})
minetest.register_abm({	
	nodenames = {"sumpf:birk"},	
	interval = 1,	
	chance = 1,	
	action = mache_birke
,})

--function anti_generate(node, surfaces, minp, maxp, height_min, height_max, spread, habitat_size, habitat_nodes) 
minetest.register_on_generated(function(minp, maxp, seed)		  
	generate("sumpf:birk", {"default:dirt_with_grass"}, minp, maxp, 20, 25, 100, 500, {"default:water_source"},30,{"default:desert_sand"})	 
end)
print("[Birke] Loaded!") 
