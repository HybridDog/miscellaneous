--[[
heaven [0.1]
License: WTFPL
]]
local ORE_ALPHA = 100
local CLOUD_ALPHA = 224
minetest.register_node(":default:sand", {
	description = "Sandcloud",
	tiles = {"default_cloud.png"},
	groups = {crumbly=3, sand=1},
	sunlight_propagates = true,
	alpha = CLOUD_ALPHA,
	sounds = default.node_sound_sand_defaults(),
})

minetest.register_node(":default:desert_sand", {
	description = "Desertcloud",
	tiles = {"default_cloud.png"},
	groups = {sand=1, crumbly=3},
	sunlight_propagates = true,
	alpha = CLOUD_ALPHA,
	sounds = default.node_sound_sand_defaults(),
})

minetest.register_node(":default:desert_stone", {
	groups = {cracky=3, stone=1},
	drop = 'default:desert_stone',
	legacy_mineral = true,
	sunlight_propagates = true,
	drawtype = "airlike",
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	air_equivalent = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":default:stone", {
	groups = {cracky=3, stone=1},
	drop = 'default:cobble',
	legacy_mineral = true,
	drawtype = "airlike",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	air_equivalent = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":default:stone_with_coal", {
	description = "Coal Orecloud",
	tiles = {"default_cloud.png^default_mineral_coal.png"},
	groups = {cracky=3},
	drop = 'default:coal_lump',
	sunlight_propagates = true,
	alpha = ORE_ALPHA,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":default:stone_with_iron", {
	description = "Iron Orecloud",
	tiles = {"default_cloud.png^default_mineral_iron.png"},
	groups = {cracky=3},
	drop = 'default:iron_lump',
	sunlight_propagates = true,
	alpha = ORE_ALPHA,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":default:dirt", {
	description = "Dirtcloud",
	tiles = {"default_cloud.png"},
	groups = {crumbly=3},
	sunlight_propagates = true,
	alpha = CLOUD_ALPHA,
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node(":default:dirt_with_grass", {
	description = "Grasscloud",
	tiles = {"default_cloud.png"},
	groups = {crumbly=3},
	drop = 'default:dirt',
	sunlight_propagates = true,
	alpha = CLOUD_ALPHA,
	sounds = default.node_sound_dirt_defaults({
		footstep = {name="default_grass_footstep", gain=0.4},
	}),
})
